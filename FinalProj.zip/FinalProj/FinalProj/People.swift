//
//  People.swift
//  FinalProj
//
//  Created by student on 2019-11-12.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class People{
    
    var allPeople = [Person]()
    
    @discardableResult func creatPerson() -> Person{
        let newPerson = Person(random: true)
        
        allPeople.append(newPerson)
        
        return newPerson
    }
    
    init(){
        for _ in 0..<5{
            creatPerson()
        }
    }
    
}
