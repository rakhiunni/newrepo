//
//  Person.swift
//  FinalProj
//
//  Created by student on 2019-11-12.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class Person: NSObject {
    var name: String
    var phoneNumber: Int?
    var birthday: String
    
    init(name: String, phoneNumber: Int?){
        self.name = name
        self.phoneNumber = phoneNumber
        birthday = "March 21st 1990"
        
        super.init()
    }
    
    convenience init(random: Bool = false){
        
        if(random){
            let firstName = ["Clark", "Peter", "Bruce"]
            let lastName = ["Kent", "Parker", "Wayne"]
            
            var idx = arc4random_uniform(UInt32(firstName.count))
            let randomFirstName = firstName[Int(idx)]
            
            idx = arc4random_uniform(UInt32(lastName.count))
            let randomLastName = lastName[Int(idx)]
            
            let randomName = "\(randomFirstName) \(randomLastName)"
            let randomPhoneNumber = Int(arc4random_uniform(100000000))
            
            self.init(name: randomName, phoneNumber: randomPhoneNumber)
        } else {
            self.init(name: "", phoneNumber: nil)
        }
        
    }
}
