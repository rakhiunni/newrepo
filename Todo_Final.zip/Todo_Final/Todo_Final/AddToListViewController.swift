//
//  AddToListViewController.swift
//  Todo_Final
//
//  Created by Rakhi Rajendran on 2019-12-07.
//  Copyright © 2019 RAKHI RAJENDRAN. All rights reserved.
//

import UIKit

class AddToListViewController: UIViewController {

    @IBOutlet weak var TitleTodo: UITextField!
    
    @IBOutlet weak var CompleteBy: UITextField!
    @IBOutlet weak var AddButton: UIButton!
    
    
    var listDeligate: ListDeligate!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func AddtoList(_ sender: Any) {
    
        guard let titletext =  TitleTodo.text else  {
            return
        }
        guard let completebytext = CompleteBy.text else{
            return
        }
        
        if titletext != "" && completebytext != ""{
            if let listDeligate = listDeligate {
                listDeligate.addtolist(item: AddTodo(todoTitle: titletext, todo_CompleteBy: completebytext))
            }
            navigationController?.popViewController(animated: true)
        }
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
