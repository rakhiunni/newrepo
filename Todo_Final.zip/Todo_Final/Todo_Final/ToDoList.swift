//
//  ToDoList.swift
//  Todo_Final
//
//  Created by Rakhi Rajendran on 2019-12-07.
//  Copyright © 2019 RAKHI RAJENDRAN. All rights reserved.
//

import Foundation

class ToDoListItems {
    
    var TodoList_items = [AddTodo]()
    
    func getList() -> [AddTodo]{
        return TodoList_items
    }
    
    func delete(index: Int){
        TodoList_items.remove(at: index)
    }
    
    func move(from: Int, to: Int){
        let temp = TodoList_items[from]
        TodoList_items.remove(at: from)
        TodoList_items.insert(temp, at: to)
    }
}
